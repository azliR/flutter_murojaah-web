// ignore_for_file: lines_longer_than_80_chars
import 'package:murojaah_web/app/model/ayah.dart';

const surah49 = [
	Ayah(
		ayahId: 4613,
		ayahText: 'يٰٓاَيُّهَا الَّذِيْنَ اٰمَنُوْا لَا تُقَدِّمُوْا بَيْنَ يَدَيِ اللّٰهِ وَرَسُوْلِهٖ وَاتَّقُوا اللّٰهَ ۗاِنَّ اللّٰهَ سَمِيْعٌ عَلِيْمٌ ',
		ayahNumber: 1,
		translationId: 'Wahai orang-orang yang beriman! Janganlah kamu mendahului Allah dan Rasul-Nya dan bertakwalah kepada Allah. Sungguh, Allah Maha Mendengar, Maha Mengetahui.',
	),
	Ayah(
		ayahId: 4614,
		ayahText: 'يٰٓاَيُّهَا الَّذِيْنَ اٰمَنُوْا لَا تَرْفَعُوْٓا اَصْوَاتَكُمْ فَوْقَ صَوْتِ النَّبِيِّ وَلَا تَجْهَرُوْا لَهٗ بِالْقَوْلِ كَجَهْرِ بَعْضِكُمْ لِبَعْضٍ اَنْ تَحْبَطَ اَعْمَالُكُمْ وَاَنْتُمْ لَا تَشْعُرُوْنَ ',
		ayahNumber: 2,
		translationId: 'Wahai orang-orang yang beriman! Janganlah kamu meninggikan suaramu melebihi suara Nabi, dan janganlah kamu berkata kepadanya dengan suara keras sebagaimana kerasnya (suara) sebagian kamu terhadap yang lain, nanti (pahala) segala amalmu bisa terhapus sedangkan kamu tidak menyadari. ',
	),
	Ayah(
		ayahId: 4615,
		ayahText: 'اِنَّ الَّذِيْنَ يَغُضُّوْنَ اَصْوَاتَهُمْ عِنْدَ رَسُوْلِ اللّٰهِ اُولٰۤىِٕكَ الَّذِيْنَ امْتَحَنَ اللّٰهُ قُلُوْبَهُمْ لِلتَّقْوٰىۗ  لَهُمْ مَّغْفِرَةٌ وَّاَجْرٌ عَظِيْمٌ ',
		ayahNumber: 3,
		translationId: 'Sesungguhnya orang-orang yang merendahkan suaranya di sisi Rasulullah, mereka itulah orang-orang yang telah diuji hatinya oleh Allah untuk bertakwa. Mereka akan memperoleh ampunan dan pahala yang besar.',
	),
	Ayah(
		ayahId: 4616,
		ayahText: 'اِنَّ الَّذِيْنَ يُنَادُوْنَكَ مِنْ وَّرَاۤءِ الْحُجُرٰتِ اَكْثَرُهُمْ لَا يَعْقِلُوْنَ ',
		ayahNumber: 4,
		translationId: 'Sesungguhnya orang-orang yang memanggil engkau (Muhammad) dari luar kamar(mu) kebanyakan mereka tidak mengerti. ',
	),
	Ayah(
		ayahId: 4617,
		ayahText: 'وَلَوْ اَنَّهُمْ صَبَرُوْا حَتّٰى تَخْرُجَ اِلَيْهِمْ لَكَانَ خَيْرًا لَّهُمْ ۗوَاللّٰهُ غَفُوْرٌ رَّحِيْمٌ',
		ayahNumber: 5,
		translationId: 'Dan sekiranya mereka bersabar sampai engkau keluar menemui mereka, tentu akan lebih baik bagi mereka. Dan Allah Maha Pengampun, Maha Penyayang. ',
	),
	Ayah(
		ayahId: 4618,
		ayahText: 'يٰٓاَيُّهَا الَّذِيْنَ اٰمَنُوْٓا اِنْ جَاۤءَكُمْ فَاسِقٌۢ بِنَبَاٍ فَتَبَيَّنُوْٓا اَنْ تُصِيْبُوْا قَوْمًاۢ بِجَهَالَةٍ فَتُصْبِحُوْا عَلٰى مَا فَعَلْتُمْ نٰدِمِيْنَ ',
		ayahNumber: 6,
		translationId: 'Wahai orang-orang yang beriman! Jika seseorang yang fasik datang kepadamu membawa suatu berita, maka telitilah kebenarannya, agar kamu tidak mencelakakan suatu kaum karena kebodohan (kecerobohan), yang akhirnya kamu menyesali perbuatanmu itu. ',
	),
	Ayah(
		ayahId: 4619,
		ayahText: 'وَاعْلَمُوْٓا اَنَّ فِيْكُمْ رَسُوْلَ اللّٰهِ ۗ لَوْ يُطِيْعُكُمْ فِيْ كَثِيْرٍ مِّنَ الْاَمْرِ لَعَنِتُّمْ وَلٰكِنَّ اللّٰهَ حَبَّبَ اِلَيْكُمُ الْاِيْمَانَ وَزَيَّنَهٗ فِيْ قُلُوْبِكُمْ وَكَرَّهَ اِلَيْكُمُ الْكُفْرَ وَالْفُسُوْقَ وَالْعِصْيَانَ ۗ اُولٰۤىِٕكَ هُمُ الرَّاشِدُوْنَۙ',
		ayahNumber: 7,
		translationId: 'Dan ketahuilah olehmu bahwa di tengah-tengah kamu ada Rasulullah. Kalau dia menuruti (kemauan) kamu dalam banyak hal pasti kamu akan mendapatkan kesusahan. Tetapi Allah menjadikan kamu cinta kepada keimanan dan menjadikan (iman) itu indah dalam hatimu serta menjadikan kamu benci kepada kekafiran, kefasikan, dan kedurhakaan. Mereka itulah orang-orang yang mengikuti jalan yang lurus,',
	),
	Ayah(
		ayahId: 4620,
		ayahText: 'فَضْلًا مِّنَ اللّٰهِ وَنِعْمَةً ۗوَاللّٰهُ عَلِيْمٌ حَكِيْمٌ ',
		ayahNumber: 8,
		translationId: 'sebagai karunia dan nikmat dari Allah. Dan Allah Maha Mengetahui, Mahabijaksana.',
	),
	Ayah(
		ayahId: 4621,
		ayahText: 'وَاِنْ طَاۤىِٕفَتٰنِ مِنَ الْمُؤْمِنِيْنَ اقْتَتَلُوْا فَاَصْلِحُوْا بَيْنَهُمَاۚ فَاِنْۢ بَغَتْ اِحْدٰىهُمَا عَلَى الْاُخْرٰى فَقَاتِلُوا الَّتِيْ تَبْغِيْ حَتّٰى تَفِيْۤءَ اِلٰٓى اَمْرِ اللّٰهِ ۖفَاِنْ فَاۤءَتْ فَاَصْلِحُوْا بَيْنَهُمَا بِالْعَدْلِ وَاَقْسِطُوْا ۗاِنَّ اللّٰهَ يُحِبُّ الْمُقْسِطِيْنَ ',
		ayahNumber: 9,
		translationId: 'Dan apabila ada dua golongan orang-orang mukmin berperang, maka damaikanlah antara keduanya. Jika salah satu dari keduanya berbuat zalim terhadap (golongan) yang lain, maka perangilah (golongan) yang berbuat zalim itu, sehingga golongan itu kembali kepada perintah Allah. Jika golongan itu telah kembali (kepada perintah Allah), maka damaikanlah antara keduanya dengan adil, dan berlakulah adil. Sungguh, Allah mencintai orang-orang yang berlaku adil. ',
	),
	Ayah(
		ayahId: 4622,
		ayahText: 'اِنَّمَا الْمُؤْمِنُوْنَ اِخْوَةٌ فَاَصْلِحُوْا بَيْنَ اَخَوَيْكُمْ  وَاتَّقُوا اللّٰهَ لَعَلَّكُمْ تُرْحَمُوْنَ ࣖ ',
		ayahNumber: 10,
		translationId: 'Sesungguhnya orang-orang mukmin itu bersaudara, karena itu damaikanlah antara kedua saudaramu (yang berselisih) dan bertakwalah kepada Allah agar kamu mendapat rahmat. ',
	),
	Ayah(
		ayahId: 4623,
		ayahText: 'يٰٓاَيُّهَا الَّذِيْنَ اٰمَنُوْا لَا يَسْخَرْ قَوْمٌ مِّنْ قَوْمٍ عَسٰٓى اَنْ يَّكُوْنُوْا خَيْرًا مِّنْهُمْ وَلَا نِسَاۤءٌ مِّنْ نِّسَاۤءٍ عَسٰٓى اَنْ يَّكُنَّ خَيْرًا مِّنْهُنَّۚ وَلَا تَلْمِزُوْٓا اَنْفُسَكُمْ وَلَا تَنَابَزُوْا بِالْاَلْقَابِۗ بِئْسَ الِاسْمُ الْفُسُوْقُ بَعْدَ الْاِيْمَانِۚ وَمَنْ لَّمْ يَتُبْ فَاُولٰۤىِٕكَ هُمُ الظّٰلِمُوْنَ ',
		ayahNumber: 11,
		translationId: 'Wahai orang-orang yang beriman! Janganlah suatu kaum mengolok-olok kaum yang lain (karena) boleh jadi mereka (yang diperolok-olokkan) lebih baik dari mereka (yang mengolok-olok) dan jangan pula perempuan-perempuan (mengolok-olokkan) perempuan lain (karena) boleh jadi perempuan (yang diperolok-olokkan) lebih baik dari perempuan (yang mengolok-olok). Janganlah kamu saling mencela satu sama lain dan janganlah saling memanggil dengan gelar-gelar yang buruk. Seburuk-buruk panggilan adalah (panggilan) yang buruk (fasik) setelah beriman. Dan barangsiapa tidak bertobat, maka mereka itulah orang-orang yang zalim. ',
	),
	Ayah(
		ayahId: 4624,
		ayahText: 'يٰٓاَيُّهَا الَّذِيْنَ اٰمَنُوا اجْتَنِبُوْا كَثِيْرًا مِّنَ الظَّنِّۖ اِنَّ بَعْضَ الظَّنِّ اِثْمٌ وَّلَا تَجَسَّسُوْا وَلَا يَغْتَبْ بَّعْضُكُمْ بَعْضًاۗ  اَيُحِبُّ اَحَدُكُمْ اَنْ يَّأْكُلَ لَحْمَ اَخِيْهِ مَيْتًا فَكَرِهْتُمُوْهُۗ وَاتَّقُوا اللّٰهَ ۗاِنَّ اللّٰهَ تَوَّابٌ رَّحِيْمٌ',
		ayahNumber: 12,
		translationId: 'Wahai orang-orang yang beriman! Jauhilah banyak dari prasangka, sesungguhnya sebagian prasangka itu dosa dan janganlah kamu mencari-cari kesalahan orang lain dan janganlah ada di antara kamu yang menggunjing sebagian yang lain. Apakah ada di antara kamu yang suka memakan daging saudaranya yang sudah mati? Tentu kamu merasa jijik. Dan bertakwalah kepada Allah, sesungguhnya Allah Maha Penerima tobat, Maha Penyayang.',
	),
	Ayah(
		ayahId: 4625,
		ayahText: 'يٰٓاَيُّهَا النَّاسُ اِنَّا خَلَقْنٰكُمْ مِّنْ ذَكَرٍ وَّاُنْثٰى وَجَعَلْنٰكُمْ شُعُوْبًا وَّقَبَاۤىِٕلَ لِتَعَارَفُوْا ۚ اِنَّ اَكْرَمَكُمْ عِنْدَ اللّٰهِ اَتْقٰىكُمْ ۗاِنَّ اللّٰهَ عَلِيْمٌ خَبِيْرٌ ',
		ayahNumber: 13,
		translationId: 'Wahai manusia! Sungguh, Kami telah menciptakan kamu dari seorang laki-laki dan seorang perempuan, kemudian Kami jadikan kamu berbangsa-bangsa dan bersuku-suku agar kamu saling mengenal. Sesungguhnya yang paling mulia di antara kamu di sisi Allah ialah orang yang paling bertakwa. Sungguh, Allah Maha Mengetahui, Mahateliti. ',
	),
	Ayah(
		ayahId: 4626,
		ayahText: '۞ قَالَتِ الْاَعْرَابُ اٰمَنَّا ۗ قُلْ لَّمْ تُؤْمِنُوْا وَلٰكِنْ قُوْلُوْٓا اَسْلَمْنَا وَلَمَّا يَدْخُلِ الْاِيْمَانُ فِيْ قُلُوْبِكُمْ ۗوَاِنْ تُطِيْعُوا اللّٰهَ وَرَسُوْلَهٗ لَا يَلِتْكُمْ مِّنْ اَعْمَالِكُمْ شَيْـًٔا ۗاِنَّ اللّٰهَ غَفُوْرٌ رَّحِيْمٌ ',
		ayahNumber: 14,
		translationId: 'Orang-orang Arab Badui berkata, “Kami telah beriman.” Katakanlah (kepada mereka), “Kamu belum beriman, tetapi katakanlah ‘Kami telah tunduk (Islam),’ karena iman belum masuk ke dalam hatimu. Dan jika kamu taat kepada Allah dan Rasul-Nya, Dia tidak akan mengurangi sedikit pun (pahala) amal perbuatanmu. Sungguh, Allah Maha Pengampun, Maha Penyayang.” ',
	),
	Ayah(
		ayahId: 4627,
		ayahText: 'اِنَّمَا الْمُؤْمِنُوْنَ الَّذِيْنَ اٰمَنُوْا بِاللّٰهِ وَرَسُوْلِهٖ ثُمَّ لَمْ يَرْتَابُوْا وَجَاهَدُوْا بِاَمْوَالِهِمْ وَاَنْفُسِهِمْ فِيْ سَبِيْلِ اللّٰهِ ۗ اُولٰۤىِٕكَ هُمُ الصّٰدِقُوْنَ ',
		ayahNumber: 15,
		translationId: 'Sesungguhnya orang-orang mukmin yang sebenarnya adalah mereka yang beriman kepada Allah dan Rasul-Nya kemudian mereka tidak ragu-ragu dan mereka berjihad dengan harta dan jiwanya di jalan Allah. Mereka itulah orang-orang yang benar.',
	),
	Ayah(
		ayahId: 4628,
		ayahText: 'قُلْ اَتُعَلِّمُوْنَ اللّٰهَ بِدِيْنِكُمْۗ وَاللّٰهُ يَعْلَمُ مَا فِى السَّمٰوٰتِ وَمَا فِى الْاَرْضِۗ وَاللّٰهُ بِكُلِّ شَيْءٍ عَلِيْمٌ ',
		ayahNumber: 16,
		translationId: 'Katakanlah (kepada mereka), “Apakah kamu akan memberitahukan kepada Allah tentang agamamu (keyakinanmu), padahal Allah mengetahui apa yang ada di langit dan apa yang ada di bumi dan Allah Maha Mengetahui segala sesuatu.” ',
	),
	Ayah(
		ayahId: 4629,
		ayahText: 'يَمُنُّوْنَ عَلَيْكَ اَنْ اَسْلَمُوْا ۗ قُلْ لَّا تَمُنُّوْا عَلَيَّ اِسْلَامَكُمْ ۚبَلِ اللّٰهُ يَمُنُّ عَلَيْكُمْ اَنْ هَدٰىكُمْ لِلْاِيْمَانِ اِنْ كُنْتُمْ صٰدِقِيْنَ ',
		ayahNumber: 17,
		translationId: 'Mereka merasa berjasa kepadamu dengan keislaman mereka. Katakanlah, “Janganlah kamu merasa berjasa kepadaku dengan keislamanmu, sebenarnya Allah yang melimpahkan nikmat kepadamu dengan menunjukkan kamu kepada keimanan, jika kamu orang yang benar.” ',
	),
	Ayah(
		ayahId: 4630,
		ayahText: 'اِنَّ اللّٰهَ يَعْلَمُ غَيْبَ السَّمٰوٰتِ وَالْاَرْضِۗ وَاللّٰهُ بَصِيْرٌۢ بِمَا تَعْمَلُوْنَ ࣖ ',
		ayahNumber: 18,
		translationId: 'Sungguh, Allah mengetahui apa yang gaib di langit dan di bumi. Dan Allah Maha Melihat apa yang kamu kerjakan. ',
	),
];
