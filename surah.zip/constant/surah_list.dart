// ignore_for_file: lines_longer_than_80_chars
import 'package:murojaah_web/app/constant/surah/surah_1.dart';
import 'package:murojaah_web/app/constant/surah/surah_10.dart';
import 'package:murojaah_web/app/constant/surah/surah_100.dart';
import 'package:murojaah_web/app/constant/surah/surah_101.dart';
import 'package:murojaah_web/app/constant/surah/surah_102.dart';
import 'package:murojaah_web/app/constant/surah/surah_103.dart';
import 'package:murojaah_web/app/constant/surah/surah_104.dart';
import 'package:murojaah_web/app/constant/surah/surah_105.dart';
import 'package:murojaah_web/app/constant/surah/surah_106.dart';
import 'package:murojaah_web/app/constant/surah/surah_107.dart';
import 'package:murojaah_web/app/constant/surah/surah_108.dart';
import 'package:murojaah_web/app/constant/surah/surah_109.dart';
import 'package:murojaah_web/app/constant/surah/surah_11.dart';
import 'package:murojaah_web/app/constant/surah/surah_110.dart';
import 'package:murojaah_web/app/constant/surah/surah_111.dart';
import 'package:murojaah_web/app/constant/surah/surah_112.dart';
import 'package:murojaah_web/app/constant/surah/surah_113.dart';
import 'package:murojaah_web/app/constant/surah/surah_114.dart';
import 'package:murojaah_web/app/constant/surah/surah_12.dart';
import 'package:murojaah_web/app/constant/surah/surah_13.dart';
import 'package:murojaah_web/app/constant/surah/surah_14.dart';
import 'package:murojaah_web/app/constant/surah/surah_15.dart';
import 'package:murojaah_web/app/constant/surah/surah_16.dart';
import 'package:murojaah_web/app/constant/surah/surah_17.dart';
import 'package:murojaah_web/app/constant/surah/surah_18.dart';
import 'package:murojaah_web/app/constant/surah/surah_19.dart';
import 'package:murojaah_web/app/constant/surah/surah_2.dart';
import 'package:murojaah_web/app/constant/surah/surah_20.dart';
import 'package:murojaah_web/app/constant/surah/surah_21.dart';
import 'package:murojaah_web/app/constant/surah/surah_22.dart';
import 'package:murojaah_web/app/constant/surah/surah_23.dart';
import 'package:murojaah_web/app/constant/surah/surah_24.dart';
import 'package:murojaah_web/app/constant/surah/surah_25.dart';
import 'package:murojaah_web/app/constant/surah/surah_26.dart';
import 'package:murojaah_web/app/constant/surah/surah_27.dart';
import 'package:murojaah_web/app/constant/surah/surah_28.dart';
import 'package:murojaah_web/app/constant/surah/surah_29.dart';
import 'package:murojaah_web/app/constant/surah/surah_3.dart';
import 'package:murojaah_web/app/constant/surah/surah_30.dart';
import 'package:murojaah_web/app/constant/surah/surah_31.dart';
import 'package:murojaah_web/app/constant/surah/surah_32.dart';
import 'package:murojaah_web/app/constant/surah/surah_33.dart';
import 'package:murojaah_web/app/constant/surah/surah_34.dart';
import 'package:murojaah_web/app/constant/surah/surah_35.dart';
import 'package:murojaah_web/app/constant/surah/surah_36.dart';
import 'package:murojaah_web/app/constant/surah/surah_37.dart';
import 'package:murojaah_web/app/constant/surah/surah_38.dart';
import 'package:murojaah_web/app/constant/surah/surah_39.dart';
import 'package:murojaah_web/app/constant/surah/surah_4.dart';
import 'package:murojaah_web/app/constant/surah/surah_40.dart';
import 'package:murojaah_web/app/constant/surah/surah_41.dart';
import 'package:murojaah_web/app/constant/surah/surah_42.dart';
import 'package:murojaah_web/app/constant/surah/surah_43.dart';
import 'package:murojaah_web/app/constant/surah/surah_44.dart';
import 'package:murojaah_web/app/constant/surah/surah_45.dart';
import 'package:murojaah_web/app/constant/surah/surah_46.dart';
import 'package:murojaah_web/app/constant/surah/surah_47.dart';
import 'package:murojaah_web/app/constant/surah/surah_48.dart';
import 'package:murojaah_web/app/constant/surah/surah_49.dart';
import 'package:murojaah_web/app/constant/surah/surah_5.dart';
import 'package:murojaah_web/app/constant/surah/surah_50.dart';
import 'package:murojaah_web/app/constant/surah/surah_51.dart';
import 'package:murojaah_web/app/constant/surah/surah_52.dart';
import 'package:murojaah_web/app/constant/surah/surah_53.dart';
import 'package:murojaah_web/app/constant/surah/surah_54.dart';
import 'package:murojaah_web/app/constant/surah/surah_55.dart';
import 'package:murojaah_web/app/constant/surah/surah_56.dart';
import 'package:murojaah_web/app/constant/surah/surah_57.dart';
import 'package:murojaah_web/app/constant/surah/surah_58.dart';
import 'package:murojaah_web/app/constant/surah/surah_59.dart';
import 'package:murojaah_web/app/constant/surah/surah_6.dart';
import 'package:murojaah_web/app/constant/surah/surah_60.dart';
import 'package:murojaah_web/app/constant/surah/surah_61.dart';
import 'package:murojaah_web/app/constant/surah/surah_62.dart';
import 'package:murojaah_web/app/constant/surah/surah_63.dart';
import 'package:murojaah_web/app/constant/surah/surah_64.dart';
import 'package:murojaah_web/app/constant/surah/surah_65.dart';
import 'package:murojaah_web/app/constant/surah/surah_66.dart';
import 'package:murojaah_web/app/constant/surah/surah_67.dart';
import 'package:murojaah_web/app/constant/surah/surah_68.dart';
import 'package:murojaah_web/app/constant/surah/surah_69.dart';
import 'package:murojaah_web/app/constant/surah/surah_7.dart';
import 'package:murojaah_web/app/constant/surah/surah_70.dart';
import 'package:murojaah_web/app/constant/surah/surah_71.dart';
import 'package:murojaah_web/app/constant/surah/surah_72.dart';
import 'package:murojaah_web/app/constant/surah/surah_73.dart';
import 'package:murojaah_web/app/constant/surah/surah_74.dart';
import 'package:murojaah_web/app/constant/surah/surah_75.dart';
import 'package:murojaah_web/app/constant/surah/surah_76.dart';
import 'package:murojaah_web/app/constant/surah/surah_77.dart';
import 'package:murojaah_web/app/constant/surah/surah_78.dart';
import 'package:murojaah_web/app/constant/surah/surah_79.dart';
import 'package:murojaah_web/app/constant/surah/surah_8.dart';
import 'package:murojaah_web/app/constant/surah/surah_80.dart';
import 'package:murojaah_web/app/constant/surah/surah_81.dart';
import 'package:murojaah_web/app/constant/surah/surah_82.dart';
import 'package:murojaah_web/app/constant/surah/surah_83.dart';
import 'package:murojaah_web/app/constant/surah/surah_84.dart';
import 'package:murojaah_web/app/constant/surah/surah_85.dart';
import 'package:murojaah_web/app/constant/surah/surah_86.dart';
import 'package:murojaah_web/app/constant/surah/surah_87.dart';
import 'package:murojaah_web/app/constant/surah/surah_88.dart';
import 'package:murojaah_web/app/constant/surah/surah_89.dart';
import 'package:murojaah_web/app/constant/surah/surah_9.dart';
import 'package:murojaah_web/app/constant/surah/surah_90.dart';
import 'package:murojaah_web/app/constant/surah/surah_91.dart';
import 'package:murojaah_web/app/constant/surah/surah_92.dart';
import 'package:murojaah_web/app/constant/surah/surah_93.dart';
import 'package:murojaah_web/app/constant/surah/surah_94.dart';
import 'package:murojaah_web/app/constant/surah/surah_95.dart';
import 'package:murojaah_web/app/constant/surah/surah_96.dart';
import 'package:murojaah_web/app/constant/surah/surah_97.dart';
import 'package:murojaah_web/app/constant/surah/surah_98.dart';
import 'package:murojaah_web/app/constant/surah/surah_99.dart';
import 'package:murojaah_web/app/model/surah.dart';

const surahs = [
  Surah(
    id: 1,
    surahName: 'Al-Fatihah',
    surahText: ' الفاتحة',
    translationId: 'Pembukaan',
    countAyah: 7,
    ayahs: surah1,
  ),
  Surah(
    id: 2,
    surahName: 'Al-Baqarah',
    surahText: ' البقرة',
    translationId: 'Sapi',
    countAyah: 286,
    ayahs: surah2,
  ),
  Surah(
    id: 3,
    surahName: "Ali 'Imran",
    surahText: ' اٰل عمران',
    translationId: 'Keluarga Imran',
    countAyah: 200,
    ayahs: surah3,
  ),
  Surah(
    id: 4,
    surahName: "An-Nisa'",
    surahText: ' النساۤء',
    translationId: 'Wanita',
    countAyah: 176,
    ayahs: surah4,
  ),
  Surah(
    id: 5,
    surahName: "Al-Ma'idah",
    surahText: ' الماۤئدة',
    translationId: 'Hidangan',
    countAyah: 120,
    ayahs: surah5,
  ),
  Surah(
    id: 6,
    surahName: "Al-An'am",
    surahText: ' الانعام',
    translationId: 'Binatang Ternak',
    countAyah: 165,
    ayahs: surah6,
  ),
  Surah(
    id: 7,
    surahName: "Al-A'raf",
    surahText: ' الاعراف',
    translationId: 'Tempat Tertinggi',
    countAyah: 206,
    ayahs: surah7,
  ),
  Surah(
    id: 8,
    surahName: 'Al-Anfal',
    surahText: ' الانفال',
    translationId: 'Rampasan Perang',
    countAyah: 75,
    ayahs: surah8,
  ),
  Surah(
    id: 9,
    surahName: 'At-Taubah',
    surahText: ' التوبة',
    translationId: 'Pengampunan',
    countAyah: 129,
    ayahs: surah9,
  ),
  Surah(
    id: 10,
    surahName: 'Yunus',
    surahText: ' يونس',
    translationId: 'Yunus',
    countAyah: 109,
    ayahs: surah10,
  ),
  Surah(
    id: 11,
    surahName: 'Hud',
    surahText: ' هود',
    translationId: 'Hud',
    countAyah: 123,
    ayahs: surah11,
  ),
  Surah(
    id: 12,
    surahName: 'Yusuf',
    surahText: ' يوسف',
    translationId: 'Yusuf',
    countAyah: 111,
    ayahs: surah12,
  ),
  Surah(
    id: 13,
    surahName: "Ar-Ra'd",
    surahText: ' الرّعد',
    translationId: 'Guruh',
    countAyah: 43,
    ayahs: surah13,
  ),
  Surah(
    id: 14,
    surahName: 'Ibrahim',
    surahText: ' ابرٰهيم',
    translationId: 'Ibrahim',
    countAyah: 52,
    ayahs: surah14,
  ),
  Surah(
    id: 15,
    surahName: 'Al-Hijr',
    surahText: ' الحجر',
    translationId: 'Hijr',
    countAyah: 99,
    ayahs: surah15,
  ),
  Surah(
    id: 16,
    surahName: 'An-Nahl',
    surahText: ' النحل',
    translationId: 'Lebah',
    countAyah: 128,
    ayahs: surah16,
  ),
  Surah(
    id: 17,
    surahName: "Al-Isra'",
    surahText: ' الاسراۤء',
    translationId: 'Memperjalankan Malam Hari',
    countAyah: 111,
    ayahs: surah17,
  ),
  Surah(
    id: 18,
    surahName: 'Al-Kahf',
    surahText: ' الكهف',
    translationId: 'Goa',
    countAyah: 110,
    ayahs: surah18,
  ),
  Surah(
    id: 19,
    surahName: 'Maryam',
    surahText: ' مريم',
    translationId: 'Maryam',
    countAyah: 98,
    ayahs: surah19,
  ),
  Surah(
    id: 20,
    surahName: 'Taha',
    surahText: ' طٰهٰ',
    translationId: 'Taha',
    countAyah: 135,
    ayahs: surah20,
  ),
  Surah(
    id: 21,
    surahName: "Al-Anbiya'",
    surahText: ' الانبياۤء',
    translationId: 'Para Nabi',
    countAyah: 112,
    ayahs: surah21,
  ),
  Surah(
    id: 22,
    surahName: 'Al-Hajj',
    surahText: ' الحج',
    translationId: 'Haji',
    countAyah: 78,
    ayahs: surah22,
  ),
  Surah(
    id: 23,
    surahName: "Al-Mu'minun",
    surahText: ' المؤمنون',
    translationId: 'Orang-Orang Mukmin',
    countAyah: 118,
    ayahs: surah23,
  ),
  Surah(
    id: 24,
    surahName: 'An-Nur',
    surahText: ' النّور',
    translationId: 'Cahaya',
    countAyah: 64,
    ayahs: surah24,
  ),
  Surah(
    id: 25,
    surahName: 'Al-Furqan',
    surahText: ' الفرقان',
    translationId: 'Pembeda',
    countAyah: 77,
    ayahs: surah25,
  ),
  Surah(
    id: 26,
    surahName: "Asy-Syu'ara'",
    surahText: ' الشعراۤء',
    translationId: 'Para Penyair',
    countAyah: 227,
    ayahs: surah26,
  ),
  Surah(
    id: 27,
    surahName: 'An-Naml',
    surahText: ' النمل',
    translationId: 'Semut-semut',
    countAyah: 93,
    ayahs: surah27,
  ),
  Surah(
    id: 28,
    surahName: 'Al-Qasas',
    surahText: ' القصص',
    translationId: 'Kisah-Kisah',
    countAyah: 88,
    ayahs: surah28,
  ),
  Surah(
    id: 29,
    surahName: "Al-'Ankabut",
    surahText: ' العنكبوت',
    translationId: 'Laba-Laba',
    countAyah: 69,
    ayahs: surah29,
  ),
  Surah(
    id: 30,
    surahName: 'Ar-Rum',
    surahText: ' الرّوم',
    translationId: 'Romawi',
    countAyah: 60,
    ayahs: surah30,
  ),
  Surah(
    id: 31,
    surahName: 'Luqman',
    surahText: ' لقمٰن',
    translationId: 'Luqman',
    countAyah: 34,
    ayahs: surah31,
  ),
  Surah(
    id: 32,
    surahName: 'As-Sajdah',
    surahText: ' السّجدة',
    translationId: 'Sajdah',
    countAyah: 30,
    ayahs: surah32,
  ),
  Surah(
    id: 33,
    surahName: 'Al-Ahzab',
    surahText: ' الاحزاب',
    translationId: 'Golongan Yang Bersekutu',
    countAyah: 73,
    ayahs: surah33,
  ),
  Surah(
    id: 34,
    surahName: "Saba'",
    surahText: ' سبأ',
    translationId: "Saba'",
    countAyah: 54,
    ayahs: surah34,
  ),
  Surah(
    id: 35,
    surahName: 'Fatir',
    surahText: ' فاطر',
    translationId: 'Maha Pencipta',
    countAyah: 45,
    ayahs: surah35,
  ),
  Surah(
    id: 36,
    surahName: 'Yasin',
    surahText: ' يٰسۤ',
    translationId: 'Yasin',
    countAyah: 83,
    ayahs: surah36,
  ),
  Surah(
    id: 37,
    surahName: 'As-Saffat',
    surahText: ' الصّٰۤفّٰت',
    translationId: 'Barisan-Barisan',
    countAyah: 182,
    ayahs: surah37,
  ),
  Surah(
    id: 38,
    surahName: 'Sad',
    surahText: ' ص',
    translationId: 'Sad',
    countAyah: 88,
    ayahs: surah38,
  ),
  Surah(
    id: 39,
    surahName: 'Az-Zumar',
    surahText: ' الزمر',
    translationId: 'Rombongan',
    countAyah: 75,
    ayahs: surah39,
  ),
  Surah(
    id: 40,
    surahName: 'Gafir',
    surahText: ' غافر',
    translationId: 'Maha Pengampun',
    countAyah: 85,
    ayahs: surah40,
  ),
  Surah(
    id: 41,
    surahName: 'Fussilat',
    surahText: ' فصّلت',
    translationId: 'Yang Dijelaskan',
    countAyah: 54,
    ayahs: surah41,
  ),
  Surah(
    id: 42,
    surahName: 'Asy-Syura',
    surahText: ' الشورى',
    translationId: 'Musyawarah',
    countAyah: 53,
    ayahs: surah42,
  ),
  Surah(
    id: 43,
    surahName: 'Az-Zukhruf',
    surahText: ' الزخرف',
    translationId: 'Perhiasan',
    countAyah: 89,
    ayahs: surah43,
  ),
  Surah(
    id: 44,
    surahName: 'Ad-Dukhan',
    surahText: ' الدخان',
    translationId: 'Kabut',
    countAyah: 59,
    ayahs: surah44,
  ),
  Surah(
    id: 45,
    surahName: 'Al-Jasiyah',
    surahText: ' الجاثية',
    translationId: 'Berlutut',
    countAyah: 37,
    ayahs: surah45,
  ),
  Surah(
    id: 46,
    surahName: 'Al-Ahqaf',
    surahText: ' الاحقاف',
    translationId: 'Bukit Pasir',
    countAyah: 35,
    ayahs: surah46,
  ),
  Surah(
    id: 47,
    surahName: 'Muhammad',
    surahText: ' محمّد',
    translationId: 'Muhammad',
    countAyah: 38,
    ayahs: surah47,
  ),
  Surah(
    id: 48,
    surahName: 'Al-Fath',
    surahText: ' الفتح',
    translationId: 'Kemenangan',
    countAyah: 29,
    ayahs: surah48,
  ),
  Surah(
    id: 49,
    surahName: 'Al-Hujurat',
    surahText: ' الحجرٰت',
    translationId: 'Kamar-Kamar',
    countAyah: 18,
    ayahs: surah49,
  ),
  Surah(
    id: 50,
    surahName: 'Qaf',
    surahText: ' ق',
    translationId: 'Qaf',
    countAyah: 45,
    ayahs: surah50,
  ),
  Surah(
    id: 51,
    surahName: 'Az-Zariyat',
    surahText: ' الذّٰريٰت',
    translationId: 'Angin yang Menerbangkan',
    countAyah: 60,
    ayahs: surah51,
  ),
  Surah(
    id: 52,
    surahName: 'At-Tur',
    surahText: ' الطور',
    translationId: 'Bukit Tursina',
    countAyah: 49,
    ayahs: surah52,
  ),
  Surah(
    id: 53,
    surahName: 'An-Najm',
    surahText: ' النجم',
    translationId: 'Bintang',
    countAyah: 62,
    ayahs: surah53,
  ),
  Surah(
    id: 54,
    surahName: 'Al-Qamar',
    surahText: ' القمر',
    translationId: 'Bulan',
    countAyah: 55,
    ayahs: surah54,
  ),
  Surah(
    id: 55,
    surahName: 'Ar-Rahman',
    surahText: ' الرحمن',
    translationId: 'Maha Pengasih',
    countAyah: 78,
    ayahs: surah55,
  ),
  Surah(
    id: 56,
    surahName: "Al-Waqi'ah",
    surahText: ' الواقعة',
    translationId: 'Hari Kiamat',
    countAyah: 96,
    ayahs: surah56,
  ),
  Surah(
    id: 57,
    surahName: 'Al-Hadid',
    surahText: ' الحديد',
    translationId: 'Besi',
    countAyah: 29,
    ayahs: surah57,
  ),
  Surah(
    id: 58,
    surahName: 'Al-Mujadalah',
    surahText: ' المجادلة',
    translationId: 'Gugatan',
    countAyah: 22,
    ayahs: surah58,
  ),
  Surah(
    id: 59,
    surahName: 'Al-Hasyr',
    surahText: ' الحشر',
    translationId: 'Pengusiran',
    countAyah: 24,
    ayahs: surah59,
  ),
  Surah(
    id: 60,
    surahName: 'Al-Mumtahanah',
    surahText: ' الممتحنة',
    translationId: 'Wanita Yang Diuji',
    countAyah: 13,
    ayahs: surah60,
  ),
  Surah(
    id: 61,
    surahName: 'As-Saff',
    surahText: ' الصّفّ',
    translationId: 'Barisan',
    countAyah: 14,
    ayahs: surah61,
  ),
  Surah(
    id: 62,
    surahName: "Al-Jumu'ah",
    surahText: ' الجمعة',
    translationId: 'Jumat',
    countAyah: 11,
    ayahs: surah62,
  ),
  Surah(
    id: 63,
    surahName: 'Al-Munafiqun',
    surahText: ' المنٰفقون',
    translationId: 'Orang-Orang Munafik',
    countAyah: 11,
    ayahs: surah63,
  ),
  Surah(
    id: 64,
    surahName: 'At-Tagabun',
    surahText: ' التغابن',
    translationId: 'Pengungkapan Kesalahan',
    countAyah: 18,
    ayahs: surah64,
  ),
  Surah(
    id: 65,
    surahName: 'At-Talaq',
    surahText: ' الطلاق',
    translationId: 'Talak',
    countAyah: 12,
    ayahs: surah65,
  ),
  Surah(
    id: 66,
    surahName: 'At-Tahrim',
    surahText: ' التحريم',
    translationId: 'Pengharaman',
    countAyah: 12,
    ayahs: surah66,
  ),
  Surah(
    id: 67,
    surahName: 'Al-Mulk',
    surahText: ' الملك',
    translationId: 'Kerajaan',
    countAyah: 30,
    ayahs: surah67,
  ),
  Surah(
    id: 68,
    surahName: 'Al-Qalam',
    surahText: ' القلم',
    translationId: 'Pena',
    countAyah: 52,
    ayahs: surah68,
  ),
  Surah(
    id: 69,
    surahName: 'Al-Haqqah',
    surahText: ' الحاۤقّة',
    translationId: 'Hari Kiamat',
    countAyah: 52,
    ayahs: surah69,
  ),
  Surah(
    id: 70,
    surahName: "Al-Ma'arij",
    surahText: ' المعارج',
    translationId: 'Tempat Naik',
    countAyah: 44,
    ayahs: surah70,
  ),
  Surah(
    id: 71,
    surahName: 'Nuh',
    surahText: ' نوح',
    translationId: 'Nuh',
    countAyah: 28,
    ayahs: surah71,
  ),
  Surah(
    id: 72,
    surahName: 'Al-Jinn',
    surahText: ' الجن',
    translationId: 'Jin',
    countAyah: 28,
    ayahs: surah72,
  ),
  Surah(
    id: 73,
    surahName: 'Al-Muzzammil',
    surahText: ' المزّمّل',
    translationId: 'Orang Yang Berselimut',
    countAyah: 20,
    ayahs: surah73,
  ),
  Surah(
    id: 74,
    surahName: 'Al-Muddassir',
    surahText: ' المدّثّر',
    translationId: 'Orang Yang Berkemul',
    countAyah: 56,
    ayahs: surah74,
  ),
  Surah(
    id: 75,
    surahName: 'Al-Qiyamah',
    surahText: ' القيٰمة',
    translationId: 'Hari Kiamat',
    countAyah: 40,
    ayahs: surah75,
  ),
  Surah(
    id: 76,
    surahName: 'Al-Insan',
    surahText: ' الانسان',
    translationId: 'Manusia',
    countAyah: 31,
    ayahs: surah76,
  ),
  Surah(
    id: 77,
    surahName: 'Al-Mursalat',
    surahText: ' المرسلٰت',
    translationId: 'Malaikat Yang Diutus',
    countAyah: 50,
    ayahs: surah77,
  ),
  Surah(
    id: 78,
    surahName: "An-Naba'",
    surahText: ' النبأ',
    translationId: 'Berita Besar',
    countAyah: 40,
    ayahs: surah78,
  ),
  Surah(
    id: 79,
    surahName: "An-Nazi'at",
    surahText: ' النّٰزعٰت',
    translationId: 'Malaikat Yang Mencabut',
    countAyah: 46,
    ayahs: surah79,
  ),
  Surah(
    id: 80,
    surahName: "'Abasa",
    surahText: ' عبس',
    translationId: 'Bermuka Masam',
    countAyah: 42,
    ayahs: surah80,
  ),
  Surah(
    id: 81,
    surahName: 'At-Takwir',
    surahText: ' التكوير',
    translationId: 'Penggulungan',
    countAyah: 29,
    ayahs: surah81,
  ),
  Surah(
    id: 82,
    surahName: 'Al-Infitar',
    surahText: ' الانفطار',
    translationId: 'Terbelah',
    countAyah: 19,
    ayahs: surah82,
  ),
  Surah(
    id: 83,
    surahName: 'Al-Mutaffifin',
    surahText: ' المطفّفين',
    translationId: 'Orang-Orang Curang',
    countAyah: 36,
    ayahs: surah83,
  ),
  Surah(
    id: 84,
    surahName: 'Al-Insyiqaq',
    surahText: ' الانشقاق',
    translationId: 'Terbelah',
    countAyah: 25,
    ayahs: surah84,
  ),
  Surah(
    id: 85,
    surahName: 'Al-Buruj',
    surahText: ' البروج',
    translationId: 'Gugusan Bintang',
    countAyah: 22,
    ayahs: surah85,
  ),
  Surah(
    id: 86,
    surahName: 'At-Tariq',
    surahText: ' الطارق',
    translationId: 'Yang Datang Di Malam Hari',
    countAyah: 17,
    ayahs: surah86,
  ),
  Surah(
    id: 87,
    surahName: "Al-A'la",
    surahText: ' الاعلى',
    translationId: 'Maha Tinggi',
    countAyah: 19,
    ayahs: surah87,
  ),
  Surah(
    id: 88,
    surahName: 'Al-Gasyiyah',
    surahText: ' الغاشية',
    translationId: 'Hari Kiamat',
    countAyah: 26,
    ayahs: surah88,
  ),
  Surah(
    id: 89,
    surahName: 'Al-Fajr',
    surahText: ' الفجر',
    translationId: 'Fajar',
    countAyah: 30,
    ayahs: surah89,
  ),
  Surah(
    id: 90,
    surahName: 'Al-Balad',
    surahText: ' البلد',
    translationId: 'Negeri',
    countAyah: 20,
    ayahs: surah90,
  ),
  Surah(
    id: 91,
    surahName: 'Asy-Syams',
    surahText: ' الشمس',
    translationId: 'Matahari',
    countAyah: 15,
    ayahs: surah91,
  ),
  Surah(
    id: 92,
    surahName: 'Al-Lail',
    surahText: ' الّيل',
    translationId: 'Malam',
    countAyah: 21,
    ayahs: surah92,
  ),
  Surah(
    id: 93,
    surahName: 'Ad-Duha',
    surahText: ' الضحى',
    translationId: 'Duha',
    countAyah: 11,
    ayahs: surah93,
  ),
  Surah(
    id: 94,
    surahName: 'Asy-Syarh',
    surahText: ' الشرح',
    translationId: 'Lapang',
    countAyah: 8,
    ayahs: surah94,
  ),
  Surah(
    id: 95,
    surahName: 'At-Tin',
    surahText: ' التين',
    translationId: 'Buah Tin',
    countAyah: 8,
    ayahs: surah95,
  ),
  Surah(
    id: 96,
    surahName: "Al-'Alaq",
    surahText: ' العلق',
    translationId: 'Segumpal Darah',
    countAyah: 19,
    ayahs: surah96,
  ),
  Surah(
    id: 97,
    surahName: 'Al-Qadr',
    surahText: ' القدر',
    translationId: 'Kemuliaan',
    countAyah: 5,
    ayahs: surah97,
  ),
  Surah(
    id: 98,
    surahName: 'Al-Bayyinah',
    surahText: ' البيّنة',
    translationId: 'Bukti Nyata',
    countAyah: 8,
    ayahs: surah98,
  ),
  Surah(
    id: 99,
    surahName: 'Az-Zalzalah',
    surahText: ' الزلزلة',
    translationId: 'Guncangan',
    countAyah: 8,
    ayahs: surah99,
  ),
  Surah(
    id: 100,
    surahName: "Al-'Adiyat",
    surahText: ' العٰديٰت',
    translationId: 'Kuda Yang Berlari Kencang',
    countAyah: 11,
    ayahs: surah100,
  ),
  Surah(
    id: 101,
    surahName: "Al-Qari'ah",
    surahText: ' القارعة',
    translationId: 'Hari Kiamat',
    countAyah: 11,
    ayahs: surah101,
  ),
  Surah(
    id: 102,
    surahName: 'At-Takasur',
    surahText: ' التكاثر',
    translationId: 'Bermegah-Megahan',
    countAyah: 8,
    ayahs: surah102,
  ),
  Surah(
    id: 103,
    surahName: "Al-'Asr",
    surahText: ' العصر',
    translationId: 'Asar',
    countAyah: 3,
    ayahs: surah103,
  ),
  Surah(
    id: 104,
    surahName: 'Al-Humazah',
    surahText: ' الهمزة',
    translationId: 'Pengumpat',
    countAyah: 9,
    ayahs: surah104,
  ),
  Surah(
    id: 105,
    surahName: 'Al-Fil',
    surahText: ' الفيل',
    translationId: 'Gajah',
    countAyah: 5,
    ayahs: surah105,
  ),
  Surah(
    id: 106,
    surahName: 'Quraisy',
    surahText: ' قريش',
    translationId: 'Quraisy',
    countAyah: 4,
    ayahs: surah106,
  ),
  Surah(
    id: 107,
    surahName: "Al-Ma'un",
    surahText: ' الماعون',
    translationId: 'Barang Yang Berguna',
    countAyah: 7,
    ayahs: surah107,
  ),
  Surah(
    id: 108,
    surahName: 'Al-Kausar',
    surahText: ' الكوثر',
    translationId: 'Pemberian Yang Banyak',
    countAyah: 3,
    ayahs: surah108,
  ),
  Surah(
    id: 109,
    surahName: 'Al-Kafirun',
    surahText: ' الكٰفرون',
    translationId: 'Orang-Orang kafir',
    countAyah: 6,
    ayahs: surah109,
  ),
  Surah(
    id: 110,
    surahName: 'An-Nasr',
    surahText: ' النصر',
    translationId: 'Pertolongan',
    countAyah: 3,
    ayahs: surah110,
  ),
  Surah(
    id: 111,
    surahName: 'Al-Lahab',
    surahText: ' اللهب',
    translationId: 'Api Yang Bergejolak',
    countAyah: 5,
    ayahs: surah111,
  ),
  Surah(
    id: 112,
    surahName: 'Al-Ikhlas',
    surahText: ' الاخلاص',
    translationId: 'Ikhlas',
    countAyah: 4,
    ayahs: surah112,
  ),
  Surah(
    id: 113,
    surahName: 'Al-Falaq',
    surahText: ' الفلق',
    translationId: 'Subuh',
    countAyah: 5,
    ayahs: surah113,
  ),
  Surah(
    id: 114,
    surahName: 'An-Nas',
    surahText: ' الناس',
    translationId: 'Manusia',
    countAyah: 6,
    ayahs: surah114,
  ),
];
